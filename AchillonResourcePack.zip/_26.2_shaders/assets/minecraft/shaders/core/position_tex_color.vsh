#version 330

// Achillon (Minecraft 26.2): the menu texture shader with the interface code of the pack (no GameTime, see the 26.3 file).
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

#moj_import <minecraft:interfaces.glsl>

in vec3 Position;
in vec2 UV0;
in vec4 Color;

uniform sampler2D Sampler0;

out vec2 texCoord0;
out vec4 vertexColor;

void main() {
    Data data = interfaces(ProjMat, 0.0, Sampler0, Position, UV0);

    gl_Position = ProjMat * ModelViewMat * vec4(data.position, 1.0);

    texCoord0 = data.uv0;
    vertexColor = Color;
}
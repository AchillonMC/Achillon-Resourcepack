#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

// ACHILLON: the full-screen Atlas (plugin Achillon_Essentials, atlas.fullscreen).
// The plugin hangs the map as text displays that sit exactly in front of the player's eyes: ATLAS_DISTANCE blocks to the south, rows of tiles side by side, each
// with the light level block 13 / sky 11 and the text opacity 254 (nothing else in the game uses either, they are the mark: one of them is enough). This shader does not draw those letters where they hang in the
// world. It draws them flat on the screen and slides the whole picture by how far the head has turned from looking due south and level: a turn to the right
// moves the map to the left, exactly like a poster, but the picture never turns, tilts or shrinks. The server only moves the head back to the middle now and then
// (and moves the map by the same amount), so the eye never sees a jump. All other text of the game goes through unchanged.
// ATLAS_DISTANCE must equal AtlasFullscreen.SHADER_DISTANCE in the plugin.
const float ATLAS_DISTANCE = 3.0;
const ivec2 ATLAS_MARK = ivec2(13 * 16, 11 * 16);
const float ATLAS_MARK_ALPHA = 254.0 / 255.0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);

    if (UV2 == ATLAS_MARK || abs(Color.a - ATLAS_MARK_ALPHA) < 0.002) {
        // Where the letter hangs in front of the eyes: to the right, up and away, in blocks (the text faces the player: its right is the world's west).
        vec3 hang = vec3(-Position.x, Position.y, Position.z);
        if (abs(hang.z - ATLAS_DISTANCE) > 1.5) {
            // The eyes are not where the map was hung (third person view): nothing to see.
            gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        } else {
            // The way the player looks, from the camera rotation: yaw 0 is south and grows turning right, pitch grows looking down.
            vec3 look = -vec3(ModelViewMat[0][2], ModelViewMat[1][2], ModelViewMat[2][2]);
            float yaw = atan(-look.x, look.z);
            float pitch = asin(clamp(-look.y, -1.0, 1.0));
            // Flat on the screen, as large as a poster would be in the middle of the view, and moved by the head.
            float x = ProjMat[0][0] * (hang.x / ATLAS_DISTANCE - yaw);
            float y = ProjMat[1][1] * (hang.y / ATLAS_DISTANCE + pitch);
            // In front of everything in the world: the depth of a point just in front of the camera, taken from the game's own projection (its clip depth range depends on the
            // graphics device, so a fixed number would be cut off on some); what hangs a little nearer to the player (the marks on the map) a little nearer still.
            float nearer = clamp((ATLAS_DISTANCE - hang.z) * 2.0, 0.0, 0.09);
            vec4 front = ProjMat * vec4(0.0, 0.0, -(0.06 - nearer * 0.1), 1.0);
            gl_Position = vec4(x * front.w, y * front.w, front.z, front.w);
        }
        // Full light, no fog.
        vertexColor = vec4(Color.rgb, 1.0);
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
    }
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}

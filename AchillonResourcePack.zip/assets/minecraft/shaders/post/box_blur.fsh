#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform BlurConfig {
    vec2 BlurDir;
    float Radius;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

// Achillon: NO BLUR. This is the game's own menu background blur shader with the radius forced to 0, so that the world behind a window (the character screen, the book dialogs, the inventory)
// stays sharp. The radius is still read (and clamped to 0 with min) so that the uniforms stay in use and the post effect keeps working; with a radius of 0 the loop does not run and the
// last line is one sample at its own place, so the picture passes through unchanged.
void main() {
    vec2 oneTexel = 1.0 / InSize;
    vec2 sampleStep = oneTexel * BlurDir;

    vec4 blurred = vec4(0.0);
    float actualRadius = min(Radius >= 0.5 ? round(Radius) : float(MenuBlurRadius), 0.0);
    for (float a = -actualRadius + 0.5; a <= actualRadius; a += 2.0) {
        blurred += texture(InSampler, texCoord + sampleStep * a);
    }
    blurred += texture(InSampler, texCoord + sampleStep * actualRadius) / 2.0;
    fragColor = blurred / (actualRadius + 0.5);
}
